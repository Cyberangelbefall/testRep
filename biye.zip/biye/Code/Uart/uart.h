#ifndef UART_H
#define UART_H

#include <reg51.h> 

void InitUART(void);

#endif