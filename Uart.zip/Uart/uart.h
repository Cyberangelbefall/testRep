#ifndef UART_H
#define UART_H

#include <reg51.h> 
#include "dht11.h" 
//#define u16 unsigned int
//#define u8 unsigned char
	
void Uart_Init(void);
void Send_Byte(uchar dat);
void Send_String(uchar *str);

#endif