#ifndef DELAY_H_ 
#define DELAY_H_


#include "dht11.h"

void DHT11_delay_us(uchar n);
void DHT11_delay_ms(uint z);
void delay_us(uchar i);
void delay_1ms(uchar i);

#endif